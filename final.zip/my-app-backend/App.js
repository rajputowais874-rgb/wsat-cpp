import axios from "axios";

// Get tasks from backend
const loadTasks = async () => {
  const res = await axios.get("http://localhost:5000/api/tasks");
  setTasks(res.data);
};

// Create task
const handleCreate = async (task) => {
  const res = await axios.post("http://localhost:5000/api/tasks", task);
  setTasks([res.data, ...tasks]);
};

// Update task (complete)
const handleComplete = async (id) => {
  const task = tasks.find(t => t._id === id);
  const res = await axios.put(`http://localhost:5000/api/tasks/${id}`, { completed: true });
  setTasks(tasks.map(t => t._id === id ? res.data : t));
};

// Delete task
const handleDelete = async (id) => {
  await axios.delete(`http://localhost:5000/api/tasks/${id}`);
  setTasks(tasks.filter(t => t._id !== id));
};
