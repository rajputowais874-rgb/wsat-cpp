import React from "react";

function TaskList({ tasks, onDelete, onComplete }) {
  if (!tasks.length) return <p>No tasks found.</p>;

  return (
    <div>
      {tasks.map((task) => (
        <div key={task._id} className={`task-item ${task.completed ? "completed" : ""}`}>
          <div>
            <strong>{task.title}</strong>
            <div style={{ fontSize: "0.85rem", color: "#555" }}>
              {task.category} | {task.description}
            </div>
          </div>
          <div>
            {!task.completed && <button className="complete" onClick={() => onComplete(task._id)}>Complete</button>}
            <button className="delete" onClick={() => onDelete(task._id)}>Delete</button>
          </div>
        </div>
      ))}
    </div>
  );
}

export default TaskList;
