import React from "react";

function Navbar() {
  return <nav>Task Dashboard</nav>;
}

export default Navbar;
