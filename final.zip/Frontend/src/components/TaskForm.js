import React, { useState } from "react";

function TaskForm({ onCreate }) {
  const [task, setTask] = useState({ title: "", category: "", description: "" });

  const handleSubmit = (e) => {
    e.preventDefault();
    if (!task.title) return;
    onCreate(task);
    setTask({ title: "", category: "", description: "" });
  };

  return (
    <div className="card">
      <h3>Create Task / Habit</h3>
      <form onSubmit={handleSubmit}>
        <input type="text" placeholder="Title" value={task.title} onChange={(e) => setTask({ ...task, title: e.target.value })} />
        <select value={task.category} onChange={(e) => setTask({ ...task, category: e.target.value })}>
          <option value="">Select Category</option>
          <option value="task">Task</option>
          <option value="habit">Habit</option>
        </select>
        <textarea placeholder="Description" value={task.description} onChange={(e) => setTask({ ...task, description: e.target.value })}></textarea>
        <button type="submit">Add Task</button>
      </form>
    </div>
  );
}

export default TaskForm;
