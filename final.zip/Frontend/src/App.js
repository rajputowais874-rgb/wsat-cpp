import React, { useState, useEffect } from "react";
import axios from "axios"; 
import Navbar from "./components/Navbar";
import TaskForm from "./components/TaskForm";
import TaskList from "./components/TaskList";
import Dashboard from "./components/Dashboard";

function App() {
  const [tasks, setTasks] = useState([]);
  const [filter, setFilter] = useState({ category: "", completed: "" });

  // 🔹 1) Fetch tasks from backend on page load
  useEffect(() => {
    axios.get("http://localhost:5000/tasks")
      .then(res => setTasks(res.data))
      .catch(err => console.log("Error fetching tasks:", err));
  }, []);

  // 🔹 2) Create task → POST to backend
  const handleCreate = async (task) => {
    try {
      const res = await axios.post("http://localhost:5000/tasks", {
        title: task.title,
        category: task.category,
        description: task.description,
        completed: false
      });

      setTasks([res.data, ...tasks]);
    } catch (err) {
      console.log("Error creating task:", err);
    }
  };

  // 🔹 3) Delete task → DELETE request
  const handleDelete = async (id) => {
    try {
      await axios.delete(`http://localhost:5000/tasks/${id}`);
      setTasks(tasks.filter(t => t._id !== id));
    } catch (err) {
      console.log("Error deleting task:", err);
    }
  };

  // 🔹 4) Mark completed → PATCH request
  const handleComplete = async (id) => {
    try {
      const res = await axios.patch(`http://localhost:5000/tasks/${id}`, {
        completed: true
      });

      setTasks(tasks.map(t => (t._id === id ? res.data : t)));
    } catch (err) {
      console.log("Error updating task:", err);
    }
  };

  // 🔹 5) Apply filters
  const filteredTasks = tasks.filter((t) => {
    if (filter.category && t.category !== filter.category) return false;
    if (filter.completed === "true" && !t.completed) return false;
    if (filter.completed === "false" && t.completed) return false;
    return true;
  });

  return (
    <>
      <Navbar />
      <div className="container">
        <div className="left">
          <Dashboard tasks={filteredTasks} />
          <TaskForm onCreate={handleCreate} />
        </div>
        <div className="right">
          <div className="card">
            <h3>Filters</h3>

            <div className="filters">
              <select onChange={(e) => setFilter({ ...filter, category: e.target.value })}>
                <option value="">All Categories</option>
                <option value="task">Task</option>
                <option value="habit">Habit</option>
              </select>

              <select onChange={(e) => setFilter({ ...filter, completed: e.target.value })}>
                <option value="">All Status</option>
                <option value="true">Completed</option>
                <option value="false">Pending</option>
              </select>
            </div>

            <TaskList 
              tasks={filteredTasks} 
              onDelete={handleDelete} 
              onComplete={handleComplete} 
            />
          </div>
        </div>
      </div>
    </>
  );
}

export default App;
