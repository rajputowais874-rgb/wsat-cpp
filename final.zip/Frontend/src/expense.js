let habits = [];

function addHabit() {
    const title = document.getElementById("title").value;
    const category = document.getElementById("category").value;
    const dueDate = document.getElementById("dueDate").value;
    const frequency = document.getElementById("frequency").value;
    const description = document.getElementById("description").value;

    if (!title || !dueDate) {
        alert("Please fill all required fields!");
        return;
    }

    const newHabit = {
        id: Date.now(),
        title,
        category,
        dueDate,
        frequency,
        description,
        status: "pending"
    };

    habits.push(newHabit);
    displayHabits();
    clearForm();
}

function displayHabits() {
    const list = document.getElementById("list");
    list.innerHTML = "";

    habits.forEach((h) => {
        const card = document.createElement("div");
        card.className = "card";

        card.innerHTML = `
            <h3>${h.title}</h3>
            <p><strong>Category:</strong> ${h.category.toUpperCase()}</p>
            <p><strong>Status:</strong> ${h.status}</p>
            <p><strong>Due:</strong> ${h.dueDate}</p>
            <p>${h.description}</p>

            <button class="complete-btn" onclick="completeHabit(${h.id})">Complete</button>
            <button class="delete-btn" onclick="deleteHabit(${h.id})">Delete</button>
        `;

        list.appendChild(card);
    });
}

function completeHabit(id) {
    habits = habits.map(h =>
        h.id === id ? { ...h, status: "completed" } : h
    );
    displayHabits();
}

function deleteHabit(id) {
    habits = habits.filter(h => h.id !== id);
    displayHabits();
}

function clearForm() {
    document.getElementById("title").value = "";
    document.getElementById("description").value = "";
    document.getElementById("dueDate").value = "";
}
