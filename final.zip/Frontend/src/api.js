const API_URL = "http://localhost:5000/api/tasks"; // change later when backend ready

export async function fetchTasks() {
  return []; // frontend only (dummy data)
}

export async function createTask(task) {
  return { ok: true, task };
}

export async function completeTask(id) {
  return { ok: true };
}

export async function deleteTask(id) {
  return { ok: true };
}
